<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Respect\Validation\Validator as v;

class ArticleController extends AbstractController
{
    /**
     * @Route("/article", name="article")
     */
    public $auteursList = [
			'news' 		=> 'Actualités',
			'recipes'	=> 'Recettes',
			'love'		=> 'Coup de coeur',
	];

    public function addArticle()
    {
    
	    if(!empty($_POST)){
			$safe = array_map('trim', array_map('strip_tags', $_POST));
			$errors = [                                                      
			(!v::notEmpty()->stringType()->length(2, 255)->validate($safe['auteur'])) ? 'Le nom de l\'auteur ou de l\'autrice doit contenir entre 2 et 255 caractères' : null,
			(!v::notEmpty()->stringType()->length(2, 255)->validate($safe['titre'])) ? 'Le titre doit contenir entre 2 et 255 caractères' : null,
			(!v::notEmpty()->stringType()->length(2, 255)->validate($safe['categorie'])) ? 'Le categorie doit contenir entre 2 et 255 caractères' : null,
			(!v::notEmpty()->stringType()->length(2, 255)->validate($safe['contenu'])) ? 'Le contenu doit contenir entre 2 et 255 caractères' : null,
			];

			$errors = array_filter($errors);
			if(count($errors) == 0){
				$success = true;
			}
			else {
				$errorsForm = implode('<br>', $errors);
			}
		}

        return $this->render('article/addArticle.html.twig', [
            'controller_name' 	=> $_POST['auteur'] ?? 'You',
            'success'	 		=> $success ?? false,
            'errors' 			=> $errorsForm ?? [],
        ]);
    }

    public function deleteArticle()
    {
    	return $this->render('article/delete.html.twig', [
            'mon_prenom' 	=> 'Alice',   
        ]);
    }

    public function editArticle()
    {
    	return $this->render('article/edit.html.twig', [
            'mon_prenom' 	=> 'Elix',
            'auteur' => $this->auteursList, // $this->categoriesList permet d'appeler la variable en dehors de la fonction addArticle()   
        ]);
    }

    public function viewArticle()
    {
    	return $this->render('article/view.html.twig', [
            'mon_prenom' 	=> 'Lola',  
        ]);
    }
}
